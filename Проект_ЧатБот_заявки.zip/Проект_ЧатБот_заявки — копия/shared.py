import os
import json
from aiogram import Bot

# Глобальная карта статусов для консистентности
STATUS_EMOJI_MAP = {
    "Редактируется": "📝",
    "Рассматривается": "🆕",
    "Ожидает подтверждения": "🤔",
    "Исполнитель найден": "🙋‍♂️",
    "Ожидает оплаты": "💳",
    "Принята": "✅",
    "В работе": "⏳",
    "Выполнена": "🎉",
    "Отменена": "❌",
    "Отправлен на проверку": "📬",
    "Утверждено администратором": "👍",
    "На доработке": "✍️",
}

ADMIN_ID = os.getenv("ADMIN_ID", "842270366")
BOT_TOKEN = os.getenv("BOT_TOKEN", "7763016986:AAFW4Rwh012_bfh8Jt0E_zaq5abvzenr4bE")
bot = Bot(token=BOT_TOKEN)

def get_all_orders() -> list:
    file_path = "orders.json"
    if not os.path.exists(file_path) or os.path.getsize(file_path) == 0:
        return []
    with open(file_path, "r", encoding="utf-8") as f:
        try:
            all_orders = json.load(f)
        except json.JSONDecodeError:
            return []
    return all_orders if isinstance(all_orders, list) else []

def get_full_name(user_or_dict):
    if isinstance(user_or_dict, dict):
        first = user_or_dict.get('first_name', '')
        last = user_or_dict.get('last_name', '')
    else:
        first = getattr(user_or_dict, 'first_name', '')
        last = getattr(user_or_dict, 'last_name', '')
    full = f"{first} {last}".strip()
    return full if full else "Без имени"

def pluralize_days(n):
    try:
        n = int(n)
    except (ValueError, TypeError):
        return str(n)
    if 11 <= n % 100 <= 14:
        return f"{n} дней"
    elif n % 10 == 1:
        return f"{n} день"
    elif 2 <= n % 10 <= 4:
        return f"{n} дня"
    else:
        return f"{n} дней" 